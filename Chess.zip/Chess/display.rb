require 'colorize'
require_relative 'board'
require_relative 'cursor'

class Display
  attr_reader :cursor

  def initialize(board)
    @board = board
    @cursor = Cursor.new([0,0], @board)
    @moves = []
  end

  def render
    i = 0
    
    @moves = @board[@cursor.cursor_pos].get_moves
    p @moves
    while i < 8
      j = 0
      while j < 8
        if [i,j] == @cursor.cursor_pos
          print "#{@board[[i,j]].to_s} ".colorize(@board[[i,j]].color).colorize(:background => :blue)
        elsif @moves.include?([i,j])
          print "#{@board[[i,j]].to_s} ".colorize(@board[[i,j]].color).colorize(:background => :light_green)
        else
          print "#{@board[[i,j]].to_s} ".colorize(@board[[i,j]].color).colorize(:background => :yellow)
        end
        j += 1
      end
      puts
      i += 1
    end
    
  end

  # def render_selected(pos)
  #   @moves = @board[pos].get_moves
  # end
end


b = Board.new
d = Display.new(b)
while true
  system("clear")
  d.render
  d.cursor.get_input
end