require_relative "piece"
# require_relative "display"
class Board

  def initialize
    @grid = Array.new(8) {Array.new(8)}
    
    # first row placement
    @grid[0][0] = Rook.new(:black, self, [0,0])
    @grid[0][7] = Rook.new(:black, self, [0,7])
    @grid[0][1] = Knight.new(:black, self, [0,1])
    @grid[0][6] = Knight.new(:black, self, [0,6])
    @grid[0][2] = Bishop.new(:black, self, [0,2])
    @grid[0][5] = Bishop.new(:black, self, [0,5])
    @grid[0][3] = Queen.new(:black, self, [0,3])
    @grid[0][4] = King.new(:black, self, [0,4])

    # second row of pawns

    j = 0
    while j < 8
        @grid[1][j] = Pawn.new(:black, self, [1, j])
        j += 1
    end
    

    #null pieces
    i = 2
    while i < 6
      j = 0
      while j < 8
        @grid[i][j] = Null_Piece.new(:orange, self, [i,j])
         j += 1
      end
      i += 1
    end
    
    # 6th row of white pawns
    j = 0
    while j < 8
        @grid[6][j] = Pawn.new(:red, self, [6, j])
        j += 1
    end

    #last row of black pieces
    @grid[7][0] = Rook.new(:red, self, [7,0])
    @grid[4][7] = Rook.new(:red, self, [4,7])
    @grid[7][1] = Knight.new(:red, self, [7,1])
    @grid[7][6] = Knight.new(:red, self, [7,6])
    @grid[4][2] = Bishop.new(:red, self, [4,2])
    @grid[7][5] = Bishop.new(:red, self, [7,5])
    @grid[3][3] = Queen.new(:red, self, [3,3])
    @grid[7][4] = King.new(:red, self, [7,4])

    @grid[7][7] = Null_Piece.new(:orange, self, [i,j])
    @grid[7][2] = Null_Piece.new(:orange, self, [i,j])
    @grid[7][3] = Null_Piece.new(:orange, self, [i,j])
  end

  def move_piece(start_pos, end_pos)
    
    if self[start_pos] == nil
      raise "No piece at this position"
    end
    # if invalid_move == true # need to flesh out
    #   raise "Can not move to that position"
    # end
    piece = self[start_pos]
    piece.pos = end_pos
    self[start_pos] = self[end_pos]
    self[end_pos].pos = start_pos
    self[end_pos] = piece

  end
  
  def []=(pos, piece)
    x,y = pos
    @grid[x][y] = piece 
  end

  def [](pos)
    x,y = pos
    @grid[x][y]
  end

  def add_piece(pos, piece)
    @grid[pos] = piece
  end

  def valid_pos?(pos)
    return true if (0..7).include?(pos[0]) && (0..7).include?(pos[1])
    false
  end

end