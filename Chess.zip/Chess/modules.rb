module Slidable_Rook
  def rook_moves
   slide_up + slide_down + slide_left + slide_right
  end
  def slide_up
    n = 1
    x,y = @pos
    arr = []

    until x-n < 0 || @board[[x-n,y]].present? 
      arr<< [x-n,y]
      n += 1
    end

    arr
  end

  def slide_down
    n = 1
    x,y = @pos
    arr = []

    until x+n > 7 || @board[[x+n,y]].present? 
      arr<< [x+n,y]
      n += 1
    end

    arr
  end

  def slide_left
    n = 1
    x,y = @pos
    arr = []

    until y-n < 0 || @board[[x,y-n]].present? 
      arr<< [x,y-n]
      n += 1
    end

    arr
  end


  def slide_right
    n = 1
    x,y = @pos
    arr = []

    until y+n > 7 || @board[[x,y+n]].present? 
      arr<< [x,y+n]
      n += 1
    end

    arr
  end


end

module Slidable_Bishop

  def bishop_moves
   slide_up_right + slide_down_right + slide_down_left + slide_up_left
  end
  
  def slide_up_right
    n = 1
    x,y = @pos
    arr = []

    until x - n < 0 || y + n > 7 || @board[[x - n,y+n]].present? 
      arr << [x - n,y+n]
      n += 1
    end

    arr
  end

  def slide_down_right
    n = 1
    x,y = @pos
    arr = []

    until x+n > 7 || y+n > 7 || @board[[x+n,y]].present? 
      arr << [x+n, y+n]
      n += 1
    end

    arr
  end

  def slide_down_left
    n = 1
    x,y = @pos
    arr = []

    until x+n > 7 || y-n < 0 || @board[[x+n,y-n]].present? 
      arr << [x + n ,y-n]
      n += 1
    end

    arr
  end


  def slide_up_left
    n = 1
    x,y = @pos
    arr = []

    until x-n < 0 || y-n < 0 || @board[[x-n, y-n]].present? 
      arr<< [x-n, y-n]
      n += 1
    end

    arr
  end



end

module Stepable_King
    MOVES = [[-1,-1], [-1,0], [-1,1], [0,1],
             [1,1], [1,0], [1,-1], [0,-1]]
  def king_moves
    
    possible_moves = MOVES.map do |move|
      [@pos[0] + move[0], @pos[1] + move[1]]
    end

    possible_moves.select do |move|
      (0..7).include?(move[0]) && (0..7).include?(move[1]) && !@board[move].present?
    end
  end

end

module Stepable_Knight

  MOVES = [[1,2], [1,-2], [-1,2], [-1,-2],
             [2,1], [2,-1], [-2,1], [-2,-1]]
  def knight_moves
    
    possible_moves = MOVES.map do |move|
      [@pos[0] + move[0], @pos[1] + move[1]]
    end

    possible_moves.select do |move|
      (0..7).include?(move[0]) && (0..7).include?(move[1]) && !@board[move].present?
    end
  end
end

module Movable_Pawn
  def pawn_moves
    moves = []
    if @color == :black
      if @has_moved == false
         moves << [@pos[0] + 1, @pos[1]] unless (@pos[0] + 1) > 7 || @board[[@pos[0] + 1, @pos[1]]].present?
         moves << [@pos[0] + 2, @pos[1]] unless (@pos[0] + 2) > 7 || @board[[@pos[0] + 2, @pos[1]]].present?
      else
        moves << [@pos[0] + 1, @pos[1]] unless (@pos[0] + 1) > 7 || @board[[@pos[0] + 1, @pos[1]]].present?
      end
    else #color is white
      if @has_moved == false
        moves << [@pos[0] - 1, @pos[1]] unless @pos[0] - 1 < 0 || @board[[@pos[0] - 1, @pos[1]]].present?
        moves << [@pos[0] - 2, @pos[1]] unless (@pos[0] - 2) > 7 || @board[[@pos[0] - 2, @pos[1]]].present?
      else
        moves << [@pos[0] - 1, @pos[1]] unless @pos[0] - 1 < 0 || @board[[@pos[0] - 1, @pos[1]]].present?
      end
    end

    moves

  end
end
