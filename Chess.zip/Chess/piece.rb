require_relative "modules"


class Piece

  include Slidable_Rook
  include Slidable_Bishop
  include Stepable_Knight
  include Stepable_King
  include Movable_Pawn

  attr_reader :color

  def initialize(color, board, pos)
    @color = color
    @board = board
    @pos = pos
   
  end

  def present?
    true
  end

  def pos=(position)
    @pos = position
  end

  def to_s
    @symbol
  end

  def get_moves
  end

end

class Null_Piece < Piece
  def initialize(color, board, pos)
    @color = color
    @symbol = :N
  end

  def present?
    false
  end

  def get_moves
    []
  end
  

end

class Rook < Piece
  
  include Slidable_Rook

 def initialize(color, board, pos)
    @symbol = "♜"
    super
  end

  def get_moves
    rook_moves
  end
  
end



class Knight < Piece
  
  include Stepable_Knight

  def initialize(color, board, pos)
    @symbol = "♞"
    super
  end

  def get_moves
    knight_moves
  end

end

class Bishop < Piece

  include Slidable_Bishop

  def initialize(color, board, pos)
    @symbol = "♝"
    super
  end

  def get_moves
    bishop_moves
  end
end

class Queen < Piece

  include Slidable_Bishop
  include Slidable_Rook

  def initialize(color, board, pos)
    @symbol = "♛"
    super
  end

  def get_moves
    bishop_moves + rook_moves
  end

end

class King < Piece

  include Stepable_King
  def initialize(color, board, pos)
      @symbol = "♚"
    super
  end

  def get_moves
    king_moves
  end

end

class Pawn < Piece
  
  include Movable_Pawn

  def initialize(color, board, pos)
    @symbol = "♙"
    @has_moved = false
    super
  end

  def get_moves
    pawn_moves
  end


end