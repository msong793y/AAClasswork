class ShortenedUrl < ApplicationRecord
  require 'securerandom'

  validates :short_url, :long_url, :user_id, presence: true
  validates :short_url, uniqueness: true

  belongs_to :creator,
    primary_key: :id,
    foreign_key: :user_id,
    class_name: :User

  def self.random_code
    s_url = SecureRandom::urlsafe_base64
    if ShortenedUrl.exists?(s_url)
      ShortenedUrl.random_code
    end
    s_url
  end

  def self.exists?(s_url)
    return false unless ShortenedUrl.find_by short_url: s_url

    true
  end

  def self.shorten_url(user, l_url)
    s_url = ShortenedUrl.random_code
    ShortenedUrl.create!(short_url: s_url, long_url: l_url, user_id: user.id)
  end
end

