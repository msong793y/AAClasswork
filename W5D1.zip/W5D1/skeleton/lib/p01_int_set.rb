class MaxIntSet
  attr_reader :store

  def initialize(max)
    @max = max
    @store= Array.new(max){false}
  end

  def insert(num)
    if is_valid?(num) 
      @store[num] = true
    else
      raise "Out of bounds"
    end
  end

  def remove(num)
    if is_valid?(num) 
      @store[num] = false
    else
      raise "Out of bounds"
    end
  end

  def include?(num)
    @store[num]
  end

  private

  def is_valid?(num)
    if num > @max || num < 0
      return false
    else
      return true
    end

  end

  def validate!(num)
  end
end


class IntSet
  attr_reader :set
  
  def initialize(num_buckets = 20)
    @set = Array.new(num_buckets) { Array.new }
  end

  def insert(num)
    modded = num % num_buckets
    @set[modded] << num
  end

  def remove(num)
    modded = num % num_buckets
    @set[modded].delete(num)
  end

  def include?(num)
    @set.each do |bucket| 
      return true if bucket.include?(num)
    end

    false
  end

  private

  def [](num)
    # optional but useful; return the bucket corresponding to `num`
  end

  def num_buckets
    @set.length
  end
end

class ResizingIntSet
  attr_reader :count

  def initialize(num_buckets = 20)
    @store = Array.new(num_buckets) { Array.new }
    @count = 0
  end

  def insert(num)
    resize! if @count >= num_buckets 

    modded = num % num_buckets
    if self.include?(num) == false
      @count += 1
      @store[modded] << num
    end

    
  end

  def remove(num)
    modded = num % num_buckets

    if self.include?(num) 
      @store[modded].delete(num)
      @count -= 1
    end

  end

  def include?(num)
    modded = num % num_buckets

    @store[modded].include?(num)
  end

  private

  def [](num)
    # optional but useful; return the bucket corresponding to `num`
  end

  def num_buckets
    @store.length
  end

  def resize!
    new_arr = Array.new(num_buckets * 2) {Array.new}
    old_arr = @store 
    @store = new_arr

    old_arr.each do |sub|
      sub.each do |ele|
        self.insert(ele)
        @count -= 1
      end
    end
  end
end
