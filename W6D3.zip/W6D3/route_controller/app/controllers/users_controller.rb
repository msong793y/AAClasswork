class UsersController < ApplicationController

  def index
    users = User.all
    render json: users
    # render plain: "I'm in the index action!"
    # render json: params
  end

  # def create

  #   user = User.create(params.require(:user).permit(:name, :email))
  #   render json: user

  # end

  def create
    user = User.new(params.require(:user).permit(:name, :email))

    if user.save
      render json: user
    else
      render json: user.errors.full_messages, status: 422
    end
  end



  def show
      render json: params
  end


private

  def param_checker
    params.require(:user).permit(:name, :email)
  end

end