# == Schema Information
#
# Table name: artworks
#
#  id         :bigint           not null, primary key
#  viewer_id  :integer          not null
#  artwork_id :integer          not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class Artwork < ApplicationRecord

  has_many :artwork,
  foreign_key: :artwork_id,
  class_name: :ArtworkShare
end
